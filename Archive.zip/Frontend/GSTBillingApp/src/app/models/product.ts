// Product Model class
export class Product {
    id:number;
    ProductID:number;
    productName:string;
    productCost:number;
    GSTproduct:number;
}
