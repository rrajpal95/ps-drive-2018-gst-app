################ GST Based Billing Application #######################

This application is based on client-server platform and provides a
convenient way for the store manager to

* Generate bills - calculated the total amount of product adds tax to it.
* Manage products - Add,Remove,Edit,Search products in the database.

This is a fullstack application build to perform CURD operations on SQL
Database.

Technologies Used :
 * SQL Database
 * Hapi.js
 * Angular 5 with Primeng

 ########################## Getting Started ############################

 Clone this repository in your local machine.

 #Extract
 Extract the zip file using any compression tool.

 #Database
 Create the database with the name and queries specified in sql.txt

 #Backed
 - Navigate to the directory
 - use 'npm install' to install the dependencies.{hapijs}
 - run 'node index' to get the server up and running.

 #Frontend

 - Navigate to the directory
 - use 'npm install' to install the dependencies.{Angular,Primeng}
 - run 'ng serve' to start the server.
