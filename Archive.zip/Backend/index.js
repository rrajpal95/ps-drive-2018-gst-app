const Hapi = require('hapi');
const mysql = require('mysql');
const Joi = require('joi');


//setting up a hapi server
const server = new Hapi.Server()
server.connection({
    host: "localhost",
    port: 3000,
    routes: {
        cors: true
    }
});



//starting the server
server.start((err) => {
    if (err) {
        throw err;
    }
    console.log(`Server running at: ${server.info.uri}`);
});

//server config
var DataBase = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: '',
    database: "billing_app_with_gst_support"
});

//Connecting to the DataBase
DataBase.connect((error) => {
    if (error) {
        console.log("Error");
        process.exit(1);
    }
    console.log("Connected");
});



//Checking the validaty of the connection
DataBase.query('SELECT 1 + 1 AS solution', function (error, results, fields) {
    if (error) throw error;
    console.log('The solution is: ', results[0].solution);
});



//route for testing
server.route({
    method: "GET",
    path: "/welcome",
    handler: (req, res) => {
        return ("MySql database");
    }
});


//aquiring GET route using ProductID for procucts
server.route({
    method: "GET",
    path: "/code/{ProductID}",
    handler: (request, h) => {
        var product_c;
        const ProductID = request.params.ProductID;
        DataBase.query("SELECT * FROM `products` WHERE `ProductID` = '" + ProductID + "'", function (error, result, fields) {
            if (error) {
                console.log("Error while querying");
                throw error;
            }
            console.log("Result from query function", result);
            var product_c = JSON.stringify(result)
            h(product_c);
        });
    },
    config: {
        validate: {
            params: {
                ProductID: Joi.number().integer()
            }
        }
    }
});

//aquiring GET route using productNamefor procucts
server.route({
    method: "GET",
    path: "/name/{productName}",
    handler: (request, h) => {
        var product_n;
        const productName = request.params.productName;
        DataBase.query("SELECT * FROM `products` WHERE `productName` = '" + productName + "'", function (error, result, fields) {
            if (error) {
                console.log("Error while querying");
                throw error;
            }
            console.log("Result from query function", result);
            var product_n = JSON.stringify(result)
            h(product_n);
        });
        //validations
        config: {
            validate: {
                params: {
                    productName: Joi.string()
                }
            }
        }
    }
});

//aquiring GET route for procucts
server.route({
    method: "GET",
    path: "/products",
    handler: (request, h) => {
        var statement = "SELECT * FROM `products`";
        var products;
        DataBase.query(statement, function (error, result, fields) {
            if (error) {
                console.log("Error while querying");
                throw error;
            }
            console.log("Result from query function", result);
            products = JSON.stringify(result);
            h(products);
        });
    }
});

//POST route to append product
server.route({
    method: "POST",
    path: "/product",
    handler: (request, h) => {
        const ProductID = request.payload.ProductID;
        const productName = request.payload.productName;
        const productCost = request.payload.productCost;
        const GSTproduct = request.payload.GSTproduct;
        var statement = "INSERT INTO `products` (`id`, `ProductID`, `productName`, `productCost`, `GSTproduct`) VALUES (NULL, '" + ProductID + "', '" + productName + "', '" + productCost + "', '" + GSTproduct + "')";
        DataBase.query(statement, function (error, result, fields) {
            if (error) {
                console.log("Error while querying");
                throw error;
            }
            console.log("Result from query function", result);
            h(result);
        });
    },
    //validations
    config: {
        validate: {
            payload: {
                productName: Joi.string(),
                ProductID: Joi.number().integer(),
                productCost: Joi.number().integer(),
                GSTproduct: Joi.number()
            }
        }
    }
});

// POST route to update existing product
server.route({
    method: "POST",
    path: "/{ProductID}",
    handler: (request, h) => {
        const ProductID = request.params.ProductID;
        const productName = request.payload.productName;
        const productCost = request.payload.productCost;
        const GSTproduct = request.payload.GSTproduct;
        var statement = "UPDATE `products` SET `productName` = '" + productName + "', `productCost` = '" + productCost + "', `GSTproduct` = '" + GSTproduct + "' WHERE `products`.`ProductID` = '" + ProductID + "'";
        DataBase.query(statement, function (error, result, fields) {
            if (error) {
                console.log("Error while querying");
                throw error;
            }
            console.log("Result from query function", result);
            h(result);
        });
    },
    //validations
    config: {
        validate: {
            payload: {
                productName: Joi.string(),
                productCost: Joi.number().integer(),
                GSTproduct: Joi.number()
            }
        }
    }
});
